import numpy as np
from scipy.optimize import nnls
from scipy.signal import find_peaks, peak_widths, peak_prominences


# --- Angular frequency omg must be in descending order!
class TikhSolver:   # --- Tikhonov + NNLS solver.
    def __init__(self, omg, zexp_re, zexp_im, mode):

        self.rpol = zexp_re[-1] - zexp_re[0]
        self.zexp_re_norm = zexp_re / self.rpol
        self.zexp_im_norm = zexp_im / self.rpol
        self.omg = omg
        self.mode = mode

        self.tau = 1 / self.omg
        self.lntau = np.log(self.tau)
        self.dlntau = self.create_dmesh(self.lntau)
        self.Idm = np.identity(self.omg.size, dtype=np.integer)
        self.am = np.zeros((self.omg.size, self.omg.size), dtype=np.float64)
        self.CreateMatrix()  # --- amTam matrix
        return

    def create_dmesh(self, grid):
        dh = np.zeros(self.omg.size, dtype=np.float64)
        for j in range(1, self.omg.size - 1):
            dh[j] = 0.5 * (grid[j + 1] - grid[j - 1])
        dh[0]  = 0.5 * (grid[1] - grid[0])
        dh[-1] = 0.5 * (grid[-1] - grid[-2])
        return dh

    def CreateMatrix(self):   # --- creates lhs matrix and rhs vector
        for i in range(self.omg.size):
            zrc = 1 / (1 + 1j * self.omg[i] * self.tau)
            if self.mode == 'real':
                self.am[i, :] = self.dlntau * zrc.real
            else:
                self.am[i, :] = - self.dlntau * zrc.imag

        self.amT = self.am.transpose()                     # --- transposed a-matrix
        self.amTam = np.matmul(self.amT, self.am)

        if self.mode == 'real':
            self.brs = np.matmul(self.amT, self.zexp_re_norm)    # --- Tikhonov right side vector
        else:
            self.brs = np.matmul(self.amT, self.zexp_im_norm)    # --- Tikhonov right side vector
        return

    def Tikh_solver(self, lamT):
        self.amTikh = self.amTam + lamT * self.Idm  # --- new Tikhonov matrix
        gtau, residuals = nnls(self.amTikh, self.brs)   # --- nnls method is used
        rpoly = np.sum(gtau * self.dlntau)   # --- dimensionless pol. resistance, should be 1
        return gtau, rpoly

    def Tikh_residual(self, lamT):   # --- returns vector of Tikhonov residuals to be minimized
        gfvec, rp = self.Tikh_solver(lamT)   # --- (new amTikh has been calculated)
        resid = np.matmul(self.amTikh, gfvec) - self.brs
        return resid

    def Tikh_residual_norm(self, gtau, lamT):    # --- returns Tikhonov residual
        self.amTikh = self.amTam + lamT * self.Idm    # --- Tikhonov matrix
        work = np.matmul(self.amTikh, gtau)
        sumres = np.linalg.norm(work - self.brs)
        sumlhs = np.linalg.norm(work**2)
        return sumres, sumlhs

    def residual_norm(self, gtau):   # --- returns residual
        work = np.matmul(self.amTam, gtau)
        normres = np.linalg.norm(work - self.brs)
        return normres

    def Zmodel_imre(self, gtau):   # --- calculates model Im(Z) / Re(Z)
        zmod = np.zeros(self.omg.size, dtype=np.float64)
        for i in range(self.omg.size):
            zrc = 1 / (1 + 1j * self.omg[i] * self.tau)
            if self.mode == 'real':
                integrand = gtau * zrc.real
            else:
                integrand = - gtau * zrc.imag
            zmod[i] = np.trapezoid(integrand, x=self.lntau)
        return np.flip(self.rpol * zmod)

    def rpol_peaks(self, gtau):   # --- finds and integrates gamma-peaks. Beta version.
        peaks, dummy = find_peaks(gtau, prominence=0.01)
        width = peak_widths(gtau, peaks, rel_height=1)

        integr = np.zeros(peaks.size, dtype=np.float64)
        for n in range(peaks.size):
            lb, ub = int(width[2][n]), int(width[3][n])
            integr[n] = np.trapezoid(gtau[lb:ub+1], x=self.lntau[lb:ub+1])

        pparms = np.zeros((3, peaks.size), dtype=np.float64)
        pparms[0, :] = np.flip(1 / (2 * np.pi * self.tau[peaks]))   # --- peak frequencies
        pparms[1, :] = np.flip(integr)                              # --- peak polarization fractions
        pparms[2, :] = np.flip(integr) * self.rpol                  # --- peak resistivities Ohm*cm2
        return pparms
