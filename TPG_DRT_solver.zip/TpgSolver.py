import numpy as np
from scipy.linalg import solve, lstsq
from scipy.signal import find_peaks


# --- Angular frequency omg must be in descending order!
class TikhPGSolver:   #--- Tikhonov + PG solver.
    def __init__(self, zexp_re, zexp_im, omg, lamT0):
        self.zexp_re = zexp_re
        self.zexp_im = zexp_im
        self.omg = omg
        self.lamT0 = lamT0
        self.rpol = zexp_re[-1]
        self.tau = 1 / self.omg
        self.dtau = self.create_dmesh(self.tau)
        self.CreateTikhMatrix()

    def create_dmesh(self, grid):
        dh = np.zeros(self.omg.size, dtype=np.float64)
        for j in range(1, self.omg.size - 1):
            dh[j] = 0.5 * (grid[j + 1] - grid[j - 1])
        dh[0]  = 0.5 * (grid[1] - grid[0])
        dh[-1] = 0.5 * (grid[-1] - grid[-2])
        return dh

    def CreateTikhMatrix(self):   # --- creates the lhs matrix and rhs vector
        self.am  = np.zeros((self.omg.size, self.omg.size), dtype=np.float64)
        self.Idm = np.identity(self.omg.size, dtype=np.integer)
        for i in range(self.omg.size):
            prod = self.omg[i] * self.tau
            self.am[i, :] = prod * self.dtau / (1 + prod**2)
        self.am *= self.rpol

        self.amT = self.am.transpose()                     # --- transposed a-matrix
        self.amTam = np.matmul(self.amT, self.am)
        self.amTikh = self.amTam + self.lamT0 * self.Idm   # --- Tikhonov matrix
        self.brs = np.matmul(self.amT, self.zexp_im)       # --- Tikhonov right side vector

    def Tikh_solver(self):   # --- solves Tikhonov equation
        sol, residuals, rank, sv = lstsq(self.amTikh, self.brs, cond=None)
        # sol = solve(self.amTikh, self.brs, assume_a='pos')
        return sol

    def pg_solver(self, lamvec):
        lamT, lampg = lamvec
        self.amTikh = self.amTam + lamT * self.Idm       # --- new Tikhonov matrix
        gamvec = self.Tikh_solver()                      # --- initial gamma from Tikhonov solver
        norm, k = 0.0, 0
        for k in range(160 * 1000):
            gk = gamvec - lampg * (np.matmul(self.amTikh, gamvec) - self.brs)
            gamvec = gk.clip(0.0)                          # --- replace negatives by 0
            if k % 10 == 0:
                norm_new = np.sum(gamvec)
                if np.abs(norm_new - norm) / norm_new < 1e-6:
                    break
                norm = norm_new
        rpoly = np.sum(gamvec * self.dtau)   # --- dimensionless pol. resistance, should be around 1
        return gamvec, rpoly, k

    def Tikh_residual_sum(self, pvec, lamT):         # --- returns mean Tikhonov residual
        self.amTikh = self.amTam + lamT * self.Idm   # --- Tikhonov matrix
        work = np.matmul(self.amTikh, pvec)
        sumres = np.sum(np.abs(work - self.brs))
        sumlhs = np.sum(np.abs(work))
        return sumres / self.omg.size, sumlhs / self.omg.size

    def Tikh_residual_vec(self, pvec, lamT):   # --- returns vector of Tikhonov residuals
        self.amTikh = self.amTam + lamT * self.Idm
        return np.matmul(self.amTikh, pvec) - self.brs

    def Zmodel_im(self, gamma_tau):   # --- calculates model Im(Z)
        zmodim = np.zeros(self.omg.size, dtype=np.float64)
        for i in range(self.omg.size):
            prod = self.omg[i] * self.tau
            integrand = prod / (1 + prod ** 2) * gamma_tau
            zmodim[i] = np.sum(self.dtau * integrand)  # --- my trapezoid
        return np.flip(self.rpol * zmodim)

    def rpol_peaks(self, gamma_tau):   # --- finds and integrates gamma-peaks. Beta version.
        peaks, dummy = find_peaks(gamma_tau, prominence=0.1)
        valleys, dummy = find_peaks(- gamma_tau, prominence=0.1)
        valleys = np.append(valleys, self.tau.size - 1)   # --- The rigthmost point is a valley
        valleys = np.insert(valleys, 0, 0)                # --- ... and the leftmost too
        integr = np.zeros(peaks.size, dtype=np.float64)
        for n in range(peaks.size):   # --- integrals are calculated starting from max frequency!
            lb, ub = valleys[n], valleys[n + 1]
            integr[n] = np.sum(gamma_tau[lb:ub] * self.dtau[lb:ub])

        vfHz = 1 / (2 * np.pi * self.tau[valleys])   # --- valleys between peaks on f-scale

        pparms = np.zeros((2, peaks.size), dtype=np.float64)
        pparms[0, :] = np.flip(1 / (2 * np.pi * self.tau[peaks]))   # --- peak frequencies
        pparms[1, :] = np.flip(integr)                   # --- peak polarization fractions
        return pparms, vfHz
