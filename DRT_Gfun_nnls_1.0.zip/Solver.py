import numpy as np
from scipy.optimize import nnls
from scipy.signal import find_peaks, peak_widths, peak_prominences


# --- Angular frequency omg must be in descending order!
class TikhSolver:   # --- Tikhonov + PG solver.
    def __init__(self, zexp_re, zexp_im, omg, mode, lamT0):
        self.rpol = zexp_re[-1] - zexp_re[0]
        self.zexp_re_norm = zexp_re / self.rpol
        self.zexp_im_norm = zexp_im / self.rpol
        self.omg = omg
        self.mode = mode
        self.lamT0 = lamT0
        self.tau = 1 / self.omg
        self.lntau = np.log(self.tau)
        self.dlntau = self.create_dmesh(self.lntau)
        self.Idm = np.identity(self.omg.size, dtype=np.integer)
        self.am = np.zeros((self.omg.size, self.omg.size), dtype=np.float64)
        self.CreateTikhMatrix()

    def create_dmesh(self, grid):
        dh = np.zeros(self.omg.size, dtype=np.float64)
        for j in range(1, self.omg.size - 1):
            dh[j] = 0.5 * (grid[j + 1] - grid[j - 1])
        dh[0]  = 0.5 * (grid[1] - grid[0])
        dh[-1] = 0.5 * (grid[-1] - grid[-2])
        return dh

    def CreateTikhMatrix(self):   # --- creates lhs matrix and rhs vector
        for i in range(self.omg.size):
            prod = self.omg[i] * self.tau
            if self.mode == 'real':
                self.am[i, :] = self.dlntau / (1 + prod**2)
            else:
                self.am[i, :] = prod * self.dlntau / (1 + prod**2)

        self.amT = self.am.transpose()                     # --- transposed a-matrix
        self.amTam = np.matmul(self.amT, self.am)
        self.amTikh = self.amTam + self.lamT0 * self.Idm   # --- Tikhonov matrix

        if self.mode == 'real':
            self.brs = np.matmul(self.amT, self.zexp_re_norm)    # --- Tikhonov right side vector
        else:
            self.brs = np.matmul(self.amT, self.zexp_im_norm)    # --- Tikhonov right side vector

    def Tikh_solver(self, lamT):
        self.amTikh = self.amTam + lamT * self.Idm  # --- new Tikhonov matrix
        gtau, residuals = nnls(self.amTikh, self.brs)   # --- nnls method is used
        rpoly = np.sum(gtau * self.dlntau)   # --- dimensionless pol. resistance, should be 1
        return gtau, rpoly

    def Tikh_residual(self, lamT):   # --- returns vector of Tikhonov residuals to be minimized
        gfvec, rp = self.Tikh_solver(lamT)   # --- (new amTikh has been calculated)
        resid = np.matmul(self.amTikh, gfvec) - self.brs
        return resid

    def Tikh_residual_norm(self, gtau, lamT):    # --- returns mean Tikhonov residual
        self.amTikh = self.amTam + lamT * self.Idm    # --- Tikhonov matrix
        work = np.matmul(self.amTikh, gtau)
        sumres = np.sqrt(np.sum((work - self.brs)**2))
        sumlhs = np.sqrt(np.sum(work**2))
        return sumres, sumlhs

    def residual_norm(self, gtau):   # --- returns residual
        work = np.matmul(self.amTam, gtau)
        normres = np.sqrt(np.sum((work - self.brs)**2))
        return normres

    def Zmodel_imre(self, gtau):   # --- calculates model Im(Z) / Re(Z)
        zmod = np.zeros(self.omg.size, dtype=np.float64)
        for i in range(self.omg.size):
            prod = self.omg[i] * self.tau
            if self.mode == 'real':
                integrand = gtau / (1 + prod ** 2)
            else:
                integrand = prod * gtau / (1 + prod ** 2)
            zmod[i] = np.sum(self.dlntau * integrand)  # --- my trapezoid
        return np.flip(self.rpol * zmod)

    def rpol_peaks(self, gtau):   # --- finds and integrates gamma-peaks. Beta version.
        peaks, dummy = find_peaks(gtau, prominence=0.01)
        width = peak_widths(gtau, peaks, rel_height=1)

        integr = np.zeros(peaks.size, dtype=np.float64)
        for n in range(peaks.size):
            lb, ub = int(width[2][n]), int(width[3][n])
            integr[n] = np.sum(gtau[lb:ub] * self.dlntau[lb:ub])

        pparms = np.zeros((2, peaks.size), dtype=np.float64)
        pparms[0, :] = np.flip(1 / (2 * np.pi * self.tau[peaks]))   # --- peak frequencies
        pparms[1, :] = np.flip(integr)                   # --- peak polarization fractions
        return pparms
