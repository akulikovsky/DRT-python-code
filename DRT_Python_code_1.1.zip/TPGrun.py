import numpy as np
import cmath as cm
from Leastsq import LeastsqMin

# --- For the main procedure and parameters see bottom part of this file

def ZWarburg():
    fmin = 0.01
    fmax = 1e4
    om = np.zeros(1, dtype=np.float64)
    om[0] = 2 * np.pi * fmin
    # alpha = 0.2328467394   # --- 11 points per decade
    alpha = 0.1103363182  # --- 22 points per decade
    # alpha = 0.07226722201  # --- 33 points per decade
    for n in range(1000):
        om = np.append(om, (1 + alpha) * om[n])
        if om[n + 1] > 2 * np.pi * fmax:
            break
    omg = np.delete(om, -1)   # --- remove last omega from the array
    omg = np.flip(omg)        # --- reverse order of elements in omega
    print('omega max =', omg[0], ', omega size = ', omg.size)
    tast = 1
    zWarb = np.array([cm.tanh(cm.sqrt(1j * tast * omg[k]))
                     / cm.sqrt(1j * tast * omg[k]) for k in range(omg.size)])
    zre = zWarb.real
    zim = - zWarb.imag

    return omg, zre, zim   # --- omg is in descending order!

def user_data():
    data = np.loadtxt(
        fname='./MyImpedance.dat',
        delimiter=', '
    )
    dflat = data.flatten()
    omg = dflat[0::3] * 2 * np.pi
    zre = dflat[1::3]
    zim = dflat[2::3]
    return omg, zre, zim


# ---------------------------------------------------
# This part of the code should be changed
# in accordance to user's problem.
# By default, calculation of Warburg finite--length
# DRT is performed.
# ---------------------------------------------------
#
fname = './results/Warburg_'   # --- directory and prefix for output file names

lamT0 = 1e-10   # --- Initial guess for Tikhonov reg. parameter
lampg0 = 0.05   # --- Initial guess for PG reg. parameter
mode = 'real'   # --- Use real part of impedance for DRT calculation.
                # --- Set mode = 'imag' to use imaginary part.

omg, zre, zim = ZWarburg()
# --- To supply your data, comment or remove the previous line and
# --- uncomment the next line:
# omg, zre, zim = user_data()
# --- The file 'MyImpedance.dat' must be placed
# --- in the directory with python codes. This file
# --- must contain 3 columns separated by commas:
# ---       f(Hz),  zre,  zim
# --- frequencies f must be in descending order and
# --- zim must be positive.
# ---------------------------------------------------
# --- By default, constrained TRF minimizer is used.
# --- To call Levenberg-Marquardt change the next
# --- line to: keylsq = 'lm'
keylsq = 'trf'
# ---------------------------------------------------

zre = zre - zre[0]   # --- subtract HFR
solver = LeastsqMin(omg, zre, zim, lamT0, lampg0, fname, mode)
solver.driver(keylsq)
