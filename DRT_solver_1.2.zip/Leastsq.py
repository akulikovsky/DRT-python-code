import numpy as np
import time
from scipy.optimize import least_squares
from scipy.linalg import norm

from TpgSolver import TikhPGSolver
from PlotsSolver import Plotter


class LeastsqMin:   # --- finds optimal lamT, lampg for TPG-iterations and returns solutions
    def __init__(self, omg, zre, zim, lamT0, lampg0, fname, mode='real'):
        self.omg = omg
        self.zexp_re = zre
        self.zexp_im = zim
        self.lamT0 = lamT0
        self.lampg0 = lampg0
        self.fname = fname
        self.mode = mode
        if mode == 'real':
            self.fsuffix = 'zre'
        else:
            self.fsuffix = 'zim'
        self.myTPG = TikhPGSolver(self.zexp_re, self.zexp_im, self.omg, self.mode, lamT0)
        self.gamma_init = self.myTPG.Tikh_solver(self.lamT0)

    def find_lambda(self):
        kmax, lam1 = 25, 1e-20
        solnorm = np.zeros(kmax, dtype=np.float64)
        resid = np.zeros(kmax, dtype=np.float64)
        lamT = np.zeros(kmax, dtype=np.float64)
        lampg = np.zeros(kmax, dtype=np.float64)
        for k in range(kmax):
            lam1 = lam1 * 10
            lamT[k] = lam1
            gam = self.myTPG.Tikh_solver(lam1)
            gfun = gam / self.omg
            resid[k] = self.myTPG.residual_norm(gam)
            solnorm[k] = np.sqrt(np.sum(gfun**2))
            lampg[k] = 1 / norm(self.myTPG.amTikh)
        return resid, solnorm, lamT, lampg

    def driver(self, lsq):   # --- omega must be in descending order!
        myplots = Plotter(self.zexp_re, self.zexp_im, self.omg, self.mode)

        resid, solnorm, arrlamT, arrlampg = self.find_lambda()
        myplots.plotLambda(resid, solnorm, arrlamT,
                           self.fname + '_lambda_T','$\lambda_T^0$')
        myplots.plotLambda(resid, solnorm, arrlampg,
                           self.fname + '_lambda_PG', '$\lambda_{pg}^0$')

        myplots.plotNyq(self.zexp_re - 1j * self.zexp_im, 'Initial spectrum')
        myplots.plotgamma(self.gamma_init, self.fname + '_init', 0, 'Tikhonov gamma')
        zmod = self.myTPG.Zmodel_imre(self.gamma_init)
        myplots.plotshow_Z(zmod, self.fname + '_init' + self.fsuffix, 0, 'Tikhonov solution')

        start = time.time()
        lamvecinit = np.array([self.lamT0, self.lampg0], dtype=np.float64)
        low, high = lamvecinit / 10, lamvecinit * 10

        if lsq == 'lm':
            resparm = least_squares(self.myTPG.Tikh_residual, lamvecinit,
                                    jac=self.myTPG.jacoby, method='lm', args=())
        else:
            resparm = least_squares(self.myTPG.Tikh_residual, lamvecinit, bounds=(low, high),
                                    jac=self.myTPG.jacoby, args=())
        res = resparm.x

        gamres, rpoly, nit = self.myTPG.pg_solver(res)
        end = time.time()
        print('Projected gradient iterations =', nit, ', rpol =', rpoly,
              ', Rpol = ', self.myTPG.rpol)
        print('lamTfit, lampgfit =', res, ', elapsed: ', (end - start), ' sec')

        resinit, lhsinit = self.myTPG.Tikh_residual_norm(self.gamma_init, self.lamT0)
        resfin , lhsfin  = self.myTPG.Tikh_residual_norm(gamres, res[0])
        print('Tikhonov residual: initial, final = ', resinit, resfin)
        print('Tikhonov lhs norm: initial, final =', lhsinit, lhsfin)
        if resparm.status > 0 :
            print('Number of Jacobian evaluations =', resparm.njev, ', status = OK')

        myplots.plotgamma(gamres, self.fname + 'gamma', 1, 'Final gamma')
        myplots.plotGfun(gamres, self.fname + 'Gfun', 1, 'Final G-function' )
        zmod = self.myTPG.Zmodel_imre(gamres)
        myplots.plotshow_Z(zmod, self.fname + self.fsuffix, 1, 'Final solution')
        peakparms, valleys = self.myTPG.rpol_peaks(gamres)

        print('Peak frequencies:   ', ''.join(['{:.5f}  '.format(item) for item in peakparms[0]]))
        print('Peak polarizations: ', ''.join(['{:.5f}  '.format(item) for item in peakparms[1]]))
