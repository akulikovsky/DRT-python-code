import numpy as np
from scipy.optimize import nnls
from scipy.signal import find_peaks, peak_widths, peak_prominences


# --- Angular frequency omg must be in descending order!
class TikhSolver:   # --- Tikhonov + NNLS solver.
    def __init__(self, omg, zexp_re, zexp_im, mode, kern):

        self.rpol = zexp_re[-1] - zexp_re[0]
        self.zexp_re_norm = zexp_re / self.rpol
        self.zexp_im_norm = zexp_im / self.rpol
        self.zexp_norm = np.concatenate([self.zexp_re_norm, self.zexp_im_norm])

        self.omg = omg
        self.mode = mode
        self.kern = kern

        self.tau = 1 / self.omg
        self.lntau = np.log(self.tau)
        self.dlntau = self.create_dmesh(self.lntau)
        self.Idm = np.identity(self.omg.size, dtype=np.int32)
        if mode == 'imre':
            self.am = np.zeros((2 * self.omg.size, self.omg.size), dtype=np.float64)
        else:
            self.am = np.zeros((self.omg.size, self.omg.size), dtype=np.float64)

        self.CreateMatrix()  # --- amTam matrix
        return

    def create_dmesh(self, grid):
        dh = np.zeros(self.omg.size, dtype=np.float64)
        for j in range(1, self.omg.size - 1):
            dh[j] = 0.5 * (grid[j + 1] - grid[j - 1])
        dh[0]  = 0.5 * (grid[1] - grid[0])
        dh[-1] = 0.5 * (grid[-1] - grid[-2])
        return dh

    def kernel(self, x):  # --- Here, x = 1j * omega[i] * tau[:], see calling statement
        if self.kern == 'cosh':
            kern = 1 / np.cosh(np.sqrt(x))
        else:
            kern = 1 / (1 + x)
        return kern

    def CreateMatrix(self):   # --- creates lhs matrix and rhs vector
        for i in range(self.omg.size):
            prod = 1j * self.omg[i] * self.tau
            zks = self.kernel(prod)                # --- Chaparro kernel

            match self.mode:
                case 'imre':
                    self.am[i] = zks.real * self.dlntau
                    self.am[i + self.omg.size] = - zks.imag * self.dlntau
                case 'imag':
                    self.am[i, :] = - zks.imag * self.dlntau
                case 'real':
                    self.am[i, :] = zks.real * self.dlntau  # --- for mode = 'real'

        self.amT = self.am.transpose()                     # --- transposed a-matrix
        self.amTam = np.matmul(self.amT, self.am)

        match self.mode:
            case 'imre':
                self.brs = np.matmul(self.amT, self.zexp_norm)   # --- Tikhonov right side vector
            case 'imag':
                self.brs = np.matmul(self.amT, self.zexp_im_norm)
            case 'real':
                self.brs = np.matmul(self.amT, self.zexp_re_norm)

        return

    def Tikh_solver(self, lamT):
        self.amTikh = self.amTam + lamT * self.Idm      # --- new Tikhonov matrix
        gtau, residuals = nnls(self.amTikh, self.brs)   # --- nnls method is used
        rpoly = np.sum(gtau * self.dlntau)              # --- dimensionless pol. resistance, should be 1
        return gtau, rpoly

    def Tikh_residual(self, lamT):           # --- returns vector of Tikhonov residuals to be minimized
        gfvec, rp = self.Tikh_solver(lamT)   # --- (new amTikh has been calculated)
        resid = np.matmul(self.amTikh, gfvec) - self.brs
        return resid

    def Tikh_residual_norm(self, gtau, lamT):    # --- returns Tikhonov residual
        self.amTikh = self.amTam + lamT * self.Idm    # --- Tikhonov matrix
        work = np.matmul(self.amTikh, gtau)
        sumres = np.linalg.norm(work - self.brs)
        sumlhs = np.linalg.norm(work**2)
        return sumres, sumlhs

    def residual_norm(self, gtau):   # --- returns residual
        work = np.matmul(self.amTam, gtau)
        normres = np.linalg.norm(work - self.brs)
        return normres

    def Zmodel_imre(self, gtau):   # --- calculates model Im(Z) / Re(Z)
        if self.mode == 'imre':
            zmod = np.zeros(self.omg.size, dtype=np.complex128)
        else:
            zmod = np.zeros(self.omg.size, dtype=np.float64)
        for i in range(self.omg.size):
            prod = 1j * self.omg[i] * self.tau
            zks = self.kernel(prod)
            integrand = gtau * np.conjugate(zks)      # -- as Im(Z) is positive
            if self.mode == 'real':
                integrand = integrand.real
            if self.mode == 'imag':
                integrand = integrand.imag

            zmod[i] = np.trapezoid(integrand, x=self.lntau)  # --- my trapezoid
        return np.flip(self.rpol * zmod)

    def zmodel_im_re(self, gtau, rc_key):   # --- calculates model Z, Im(Z), or Re(Z) from the DDT/DRT
        if self.mode == 'imre':
            zmod = np.zeros(self.omg.size, dtype=np.complex128)
        else:
            zmod = np.zeros(self.omg.size, dtype=np.float64)
        for i in range(self.omg.size):
            prod = 1j * self.omg[i] * self.tau
            zks = self.kernel(prod)
            integrand = gtau * np.conjugate(zks)      # -- as Im(Z) is positive
            if self.mode == 'real':
                integrand = integrand.real
            if self.mode == 'imag':
                integrand = integrand.imag

            zmod[i] = np.trapezoid(integrand, x=self.lntau)  # --- my trapezoid
        return np.flip(self.rpol * zmod)

    def rpol_peaks(self, gtau):   # --- finds and integrates gamma-peaks. Beta version.
        peaks, dummy = find_peaks(gtau, prominence=0.01)
        width = peak_widths(gtau, peaks, rel_height=1)

        integr = np.zeros(peaks.size, dtype=np.float64)
        for n in range(peaks.size):
            lb, ub = int(width[2][n]), int(width[3][n])
            integr[n] = np.trapezoid(gtau[lb:ub+1], x=self.lntau[lb:ub+1])

        pparms = np.zeros((3, peaks.size), dtype=np.float64)
        pparms[0, :] = np.flip(1 / (2 * np.pi * self.tau[peaks]))   # --- peak frequencies
        pparms[1, :] = np.flip(integr)                              # --- peak polarization fractions
        pparms[2, :] = np.flip(integr) * self.rpol                  # --- peak resistivities Ohm*cm2
        return pparms

    def rpol_peaks_fHz(self, gtau):   # --- finds Gfun-peaks on the fHz scale. Beta version.
        peaks, dummy = find_peaks(np.flip(gtau), prominence=0.01)
        return peaks
