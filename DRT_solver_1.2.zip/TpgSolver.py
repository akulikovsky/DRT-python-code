import numpy as np
from scipy.linalg import solve, lstsq
from scipy.signal import find_peaks

# --- Angular frequency omg must be in descending order!
class TikhPGSolver:   #--- Tikhonov + PG solver.
    def __init__(self, zexp_re, zexp_im, omg, mode, lamT0):
        self.zexp_re = zexp_re
        self.zexp_im = zexp_im
        self.omg = omg
        self.mode = mode
        self.lamT0 = lamT0
        self.rpol = zexp_re[-1]
        self.tau = 1 / self.omg
        self.dtau = self.create_dmesh(self.tau)
        self.Idm = np.identity(self.omg.size, dtype=np.integer)
        self.am = np.zeros((self.omg.size, self.omg.size), dtype=np.float64)
        self.CreateTikhMatrix()

    def create_dmesh(self, grid):
        dh = np.zeros(self.omg.size, dtype=np.float64)
        for j in range(1, self.omg.size - 1):
            dh[j] = 0.5 * (grid[j + 1] - grid[j - 1])
        dh[0]  = 0.5 * (grid[1] - grid[0])
        dh[-1] = 0.5 * (grid[-1] - grid[-2])
        return dh

    def CreateTikhMatrix(self):   # --- creates lhs matrix and rhs vector
        for i in range(self.omg.size):
            prod = self.omg[i] * self.tau
            if self.mode == 'real':
                self.am[i, :] = self.dtau / (1 + prod**2)
            else:
                self.am[i, :] = prod * self.dtau / (1 + prod**2)
        self.am *= self.rpol

        self.amT = self.am.transpose()                    # --- transposed a-matrix
        self.amTam = np.matmul(self.amT, self.am)
        self.amTikh = self.amTam + self.lamT0 * self.Idm  # --- Tikhonov matrix

        if self.mode == 'real':
            self.brs = np.matmul(self.amT, self.zexp_re)  # --- Tikhonov right side vector
            self.b = self.zexp_re
        else:
            self.brs = np.matmul(self.amT, self.zexp_im)  # --- Tikhonov right side vector
            self.b = self.zexp_im

    def Tikh_solver(self, lamt):   # --- solves Tikhonov equation
        self.amTikh = self.amTam + lamt * self.Idm  # --- new Tikhonov matrix
        sol, residuals, rank, sv = lstsq(self.amTikh, self.brs, cond=None)
        # sol = solve(self.amTikh, self.brs, assume_a='pos')
        return sol

    def pg_solver(self, lamvec):
        lamT, lampg = lamvec
        gamma_tau = self.Tikh_solver(lamT)  # --- initial gamma from Tikhonov solver
        norm, k = 0.0, 0
        for k in range(160 * 1000):
            gk = gamma_tau - lampg * (np.matmul(self.amTikh, gamma_tau) - self.brs)
            gamma_tau = gk.clip(0.0)                          # --- replace negatives by 0
            if k % 10 == 0:
                norm_new = np.sum(gamma_tau)
                if np.abs(norm_new - norm) / norm_new < 1e-6:
                    break
                norm = norm_new
        rpoly = np.sum(gamma_tau * self.dtau)   # --- dimensionless pol. resistance, should be 1
        return gamma_tau, rpoly, k

    def jacoby(self, pvec):
        jacob = np.zeros((self.omg.size, pvec.size), dtype=np.float64)
        gambase = self.Tikh_residual(pvec)
        pvecdp = np.copy(pvec)
        dp = 0.01
        for i in range(pvec.size):
            pvecdp[i] = pvec[i] * (1 + dp)
            gam = self.Tikh_residual(pvecdp)
            dgam = gam - gambase
            jacob[:, i] = dgam / (pvec[i] * dp)
            pvecdp[i] = pvec[i]
        return jacob

    def Tikh_residual(self, lamvec):   # --- returns vector of Tikhonov residuals to be minimized
        gamvec, rp, kk = self.pg_solver(lamvec)   # --- (new amTikh has been calculated)
        resid = np.matmul(self.amTikh, gamvec) - self.brs
        return resid

    def Tikh_residual_norm(self, gamma_tau, lamT):    # --- returns mean Tikhonov residual
        self.amTikh = self.amTam + lamT * self.Idm    # --- Tikhonov matrix
        work = np.matmul(self.amTikh, gamma_tau)
        sumres = np.sqrt(np.sum((work - self.brs)**2))
        sumlhs = np.sqrt(np.sum(work**2))
        return sumres, sumlhs

    def residual_norm(self, gamma_tau):   # --- returns residual
        work = np.matmul(self.am, gamma_tau)
        normres = np.sqrt(np.sum((work - self.b)**2))
        return normres

    def Zmodel_imre(self, gamma_tau):   # --- calculates model Im(Z)
        zmod = np.zeros(self.omg.size, dtype=np.float64)
        for i in range(self.omg.size):
            prod = self.omg[i] * self.tau
            if self.mode == 'real':
                integrand = 1 / (1 + prod ** 2) * gamma_tau
            else:
                integrand = prod / (1 + prod ** 2) * gamma_tau
            zmod[i] = np.sum(self.dtau * integrand)  # --- my trapezoid
        return np.flip(self.rpol * zmod)

    def rpol_peaks(self, gamma_tau):   # --- finds and integrates gamma-peaks. Beta version.
        peaks, dummy = find_peaks(gamma_tau, prominence=0.1)
        valleys, dummy = find_peaks(- gamma_tau, prominence=0.1)
        valleys = np.append(valleys, self.tau.size - 1)   # --- The rigthmost point is a valley
        valleys = np.insert(valleys, 0, 0)                # --- ... and the leftmost too
        integr = np.zeros(peaks.size, dtype=np.float64)
        for n in range(peaks.size):   # --- integrals are calculated starting from max frequency!
            lb, ub = valleys[n], valleys[n + 1]
            integr[n] = np.sum(gamma_tau[lb:ub] * self.dtau[lb:ub])

        vfHz = 1 / (2 * np.pi * self.tau[valleys])   # --- valleys between peaks on f-scale

        pparms = np.zeros((2, peaks.size), dtype=np.float64)
        pparms[0, :] = np.flip(1 / (2 * np.pi * self.tau[peaks]))   # --- peak frequencies
        pparms[1, :] = np.flip(integr)                   # --- peak polarization fractions
        return pparms, vfHz
