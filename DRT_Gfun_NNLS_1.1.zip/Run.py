import numpy as np
import cmath as cm
from Leastsq import LeastsqMin

# --- For the main procedure and parameters see bottom part of this file
def ZWarburg():
    xlin = np.linspace(-2, 4, 22 * 6)   # --- 22 points per decade
    fHz = 10 ** xlin                    # --- frequency range from 10^{-2} to 10^4, with 22 pts/decade
    omega = 2 * np.pi * fHz

    omega = np.flip(omega)        # --- reverse order of elements in omega
    tast = 1
    zWarb = np.zeros(omega.size, dtype=np.complex128)
    for k in range(omega.size):
        psi = cm.sqrt(1j * tast * omega[k])
        zWarb[k] = cm.tanh(psi) / psi

    zrew = zWarb.real
    zimw = - zWarb.imag

    return omega, zrew, zimw   # --- omega is in descending order!


def user_data(fdata):
    data = np.loadtxt(
        fname=fdata,
        delimiter=', '
    )
    dflat = data.flatten()
    omgu = dflat[0::3] * 2 * np.pi
    zreu = dflat[1::3]
    zimu = dflat[2::3]
    return omgu, zreu, zimu


# ---------------------------------------------------
# This part of the code should be changed
# in accordance with a user's problem.
# By default, calculation of Warburg finite--length
# DRT is performed.
# ---------------------------------------------------
#

fname = './results/Warburg_'   # --- Prefix for output files name
fdata = './MyImpedance.dat'

lamT = 1e-5     # --- Tikhonov regularization parameter
mode = 'imag'   # --- Use real part of impedance for DRT calculation.
                # --- Set mode = 'imag' to use imaginary part.

omg, zre, zim = ZWarburg()

# --- To supply your data, comment or remove the previous line and
# --- uncomment the next line:
# omg, zre, zim = user_data(fdata)
# --- The file 'MyImpedance.dat' must be placed
# --- in the directory with python codes. This file
# --- must contain 3 columns separated by commas:
# ---       f(Hz),  zre,  zim
# --- frequencies f must be in descending order and
# --- zim must be positive.
# ---------------------------------------------------

zre -= zre[0]

solver = LeastsqMin(omg, zre, zim, lamT, fname, mode)
solver.driver()
