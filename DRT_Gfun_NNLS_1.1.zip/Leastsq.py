import numpy as np
from Solver import TikhSolver
from PlotsSolver import Plotter


class LeastsqMin:   # --- finds optimal lamT, lampg for TPG-iterations and returns solutions
    def __init__(self, omg, zre, zim, lamT, fname, mode='real'):
        self.omg = omg
        self.zexp_re = zre
        self.zexp_im = zim
        self.lamT = lamT
        self.fname = fname
        self.mode = mode
        if mode == 'real':
            self.fsuffix = 'zre'
        else:
            self.fsuffix = 'zim'
        self.myTikh = TikhSolver(self.zexp_re, self.zexp_im, self.omg, self.mode, lamT)
        self.gfun_init, dummy = self.myTikh.Tikh_solver(self.lamT)
        self.fHz = self.omg / (2 * np.pi)
        return

    def find_lambda(self):
        kmax, lam1 = 16, 1e-16
        solnorm = np.zeros(kmax, dtype=np.float64)
        resid = np.zeros(kmax, dtype=np.float64)
        lamTikh = np.zeros(kmax, dtype=np.float64)
        for k in range(kmax):
            lam1 *= 10
            lamTikh[k] = lam1
            gfun, dum = self.myTikh.Tikh_solver(lam1)
            resid[k] = self.myTikh.residual_norm(gfun)
            solnorm[k] = np.sqrt(np.sum(gfun**2))
        return resid, solnorm, lamTikh

    def driver(self):   # --- omega must be in descending order!
        myplots = Plotter(self.zexp_re, self.zexp_im, self.omg, self.mode)

        resid, solnorm, arrlamT = self.find_lambda()
        myplots.plotLambda(resid, solnorm, arrlamT,
                           self.fname + '_lambda_T', r'$\lambda_T$', 1)
        myplots.plotNyq('Nyquist spectrum')

        gfun, rpoly = self.myTikh.Tikh_solver(self.lamT)
        print('lamT =', self.lamT)
        print('rpol =', rpoly, ', Rpol = ', self.myTikh.rpol)

        resfin , lhsfin  = self.myTikh.Tikh_residual_norm(gfun, self.lamT)
        print('Tikhonov residual: ', resfin)
        print('Tikhonov lhs norm: ', lhsfin)

        # myplots.plotgamma(gamres, self.fname + 'gamma', 1, '')
        myplots.plotGfun(gfun, self.fname + 'Gfun', 1, 'G-function')
        myplots.plotGfun_tau(self.myTikh.tau, gfun, self.fname + 'Gfun_vs_tau', 1, 'G-function')
        zmod = self.myTikh.Zmodel_imre(gfun)
        myplots.plotshow_Z(zmod, self.fname + self.fsuffix, 1, '')
        peakparms = self.myTikh.rpol_peaks(gfun)

        print('Peak frequencies (beta):   ', ''.join(['{:.5f}  '.format(item) for item in peakparms[0]]))
        print('Peak polarizations (beta): ', ''.join(['{:.5f}  '.format(item) for item in peakparms[1]]))
        print('Peak polriz Ohm*cm2(beta): ', ''.join(['{:.5f}  '.format(item) for item in peakparms[2]]))
        return
