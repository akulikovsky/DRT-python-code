import numpy as np
from Leastsq import LeastsqMin

# --- For the main procedure and parameters see bottom part of this file
def ZWarburg():
    xlin = np.linspace(-2, 4, 22 * 6)   # --- 22 points per decade
    fHz = 10 ** xlin                    # --- frequency range from 10^{-2} to 10^4, with 22 pts/decade
    omega = 2 * np.pi * fHz

    omega = np.flip(omega)        # --- reverse order of elements in omega
    tast = 1
    psi = np.sqrt(1j * tast * omega)
    zWarb = np.tanh(psi) / psi

    zrew = zWarb.real
    zimw = - zWarb.imag

    return omega, zrew, zimw   # --- omega is in descending order!


def user_data(fdata):
    data = np.loadtxt(
        fname=fdata,
        delimiter=','
    )
    omgu = data[:, 0] * 2 * np.pi
    zreu = data[:, 1]
    zimu = data[:, 2]
    return omgu, zreu, zimu


# ---------------------------------------------------
# This part of the code should be changed
# in accordance with a user's problem.
# By default, calculation of the Warburg finite--length
# DRT is performed.
# ---------------------------------------------------
#

mode = 'imre'


fname = './results/DRT_' + mode + '_'   # --- Prefix for output files name
fdata = './MyImpedance.dat'

omg, zre, zim = ZWarburg()

# --- To supply your data, remove the previous line and
# --- uncomment the next line:
# omg, zre, zim = user_data(fdata)
# --- The file 'MyImpedance.dat' must be placed
# --- in the directory with python codes. This file
# --- must contain 3 columns separated by commas:
# ---       f(Hz),  zre,  zim
# --- frequencies f must be in descending order and
# --- zim must be positive.
# ---------------------------------------------------

zre -= zre[0]

solver = LeastsqMin(omg, zre, zim, fname, mode)
solver.driver()
