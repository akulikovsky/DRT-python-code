import numpy as np
import time
from scipy.optimize import least_squares

from TpgSolver import TikhPGSolver
from PlotsSolver import Plotter


class LeastsqMin:   # --- finds optimal lamT, lampg for TPG-iterations and returns solutions
    def __init__(self, omg, zre, zim, lamT0, lampg0, fname):
        self.omg = omg
        self.zexp_re = zre
        self.zexp_im = zim
        self.lamT0 = lamT0
        self.lampg0 = lampg0
        self.fname = fname
        self.myTPG = TikhPGSolver(self.zexp_re, self.zexp_im, self.omg, lamT0)
        self.gamma_init = self.myTPG.Tikh_solver()

    def model_pg_vec(self, lamvec):   # --- returns vector of Tikhonov residuals to be minimized
        self.gam, rp, kk = self.myTPG.pg_solver(lamvec)
        resid = self.myTPG.Tikh_residual_vec(self.gam, lamvec[0])   # --- lamvec[0] = lamT
        return resid

    def jacoby(self, pvec):   # --- Numerical Jacobian. pvec = np.array([lamT, lampg])
        jacob = np.zeros((self.omg.size, pvec.size), dtype=np.float64)
        gambase = self.model_pg_vec(pvec)
        dp = 0.01
        pvecalldp = np.copy(pvec)
        for i in range(pvec.size):
            pvecalldp[i] = pvec[i] * (1 + dp)
            gam = self.model_pg_vec(pvecalldp)
            dgam = gam - gambase
            jacob[:, i] = dgam / (pvec[i] * dp)
            pvecalldp[i] = pvec[i]
        return jacob

    def driver(self, lsq):   # --- omega must be in descending order!
        myplots = Plotter(self.zexp_re, self.zexp_im, self.omg)

        myplots.plotNyq(self.zexp_re - 1j * self.zexp_im)
        myplots.plotgamma(self.gamma_init, self.fname + '_init', 0)
        zmod_im = self.myTPG.Zmodel_im(self.gamma_init)
        myplots.plotshow_Zim(zmod_im, self.fname + '_init_zim', 0)

        start = time.time()
        lamvecinit = np.array([self.lamT0, self.lampg0], dtype=np.float64)
        low, high = lamvecinit / 10, lamvecinit * 10

        if lsq == 'lm':
            resparm = least_squares(self.model_pg_vec, lamvecinit,
                                    jac=self.jacoby, method='lm', args=())
        else:
            resparm = least_squares(self.model_pg_vec, lamvecinit, bounds=(low, high),
                                    jac=self.jacoby, args=())
        res = resparm.x

        gamres, rpoly, nit = self.myTPG.pg_solver(res)
        end = time.time()
        print('Projected gradient iterations =', nit, ', rpol =', rpoly,
              ', Rpol = ', self.myTPG.rpol)
        print('lamTfit, lampgfit =', res, ', elapsed: ', (end - start), ' sec')

        resinit, lhsinit = self.myTPG.Tikh_residual_sum(self.gamma_init, self.lamT0)
        resfin , lhsfin  = self.myTPG.Tikh_residual_sum(gamres, res[0])
        print('Tikhonov residual: initial, final = ', resinit, resfin)
        print('Tikhonov lhs norm: initial, final =', lhsinit, lhsfin)

        myplots.plotgamma(gamres, self.fname + 'gamma', 1)
        myplots.plotGfun(gamres, self.fname + 'Gfun', 1)
        zmod_im = self.myTPG.Zmodel_im(gamres)
        myplots.plotshow_Zim(zmod_im, self.fname + 'zim', 1)
        peakparms, valleys = self.myTPG.rpol_peaks(gamres)

        print('Peak frequencies:   ', ''.join(['{:.5f}  '.format(item) for item in peakparms[0]]))
        print('Peak polarizations: ', ''.join(['{:.5f}  '.format(item) for item in peakparms[1]]))
