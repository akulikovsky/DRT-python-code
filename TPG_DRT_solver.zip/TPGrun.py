import numpy as np
import cmath as cm
from Leastsq import LeastsqMin

def ZWarburg():
    fmin = 0.01
    fmax = 1e4
    om = np.zeros(1, dtype=np.float64)
    om[0] = 2 * np.pi * fmin
    # alpha = 0.2328467394   # --- 11 points per decade
    alpha = 0.1103363182  # --- 22 points per decade
    # alpha = 0.07226722201  # --- 33 points per decade
    for n in range(1000):
        om = np.append(om, (1 + alpha) * om[n])
        if om[n + 1] > 2 * np.pi * fmax:
            break
    omg = np.delete(om, -1)
    omg = np.flip(omg)
    print('omega max =', omg[0], ', omega size = ', omg.size)
    tast = 1
    zrc2 = np.array([cm.tanh(cm.sqrt(1j * tast * omg[k]))
                     / cm.sqrt(1j * tast * omg[k]) for k in range(omg.size)])
    zre = zrc2.real
    zim = - zrc2.imag

    return omg, zre, zim   # --- omg is in descending order!

def user_data():
    data = np.loadtxt(
        fname='./MyImpedance.dat',
        delimiter=' '
    )
    dflat = data.flatten()
    omg = dflat[0::3] * 2 * np.pi
    zre = dflat[1::3]
    zim = dflat[2::3]
    return omg, zre, zim


# ---------------------------------------------------
# --- By default, constrained TRF minimizer is used.
# --- To call Levenberg-Marquardt change the next
# --- line to: keylsq = 'lm'
keylsq = 'trf'
# ---------------------------------------------------

fname = './results/Warburg_'   # --- directory and prefix for output file names

lamT0 = 1e-9   # --- Initial guess for Tikhonov reg. parameter
lampg0 = 1     # --- Initial guess for PG reg. parameter

omg, zre, zim = ZWarburg()
# --- To supply your data, remove the previous line and
# --- uncomment the following line:
# omg, zre, zim = user_data()
# --- The file 'MyImpedance.dat' must be placed
# --- in the directory with python codes. This file
# --- must contain 3 columns separated by space:
# ---       f(Hz)  zre  zim
# --- frequencies f must be in descending order and
# --- zim must be positive.
# -----------------------------------

solver = LeastsqMin(omg, zre, zim, lamT0, lampg0, fname)
solver.driver(keylsq)
