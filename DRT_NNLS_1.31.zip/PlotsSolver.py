import matplotlib.pyplot as plt
import numpy as np

xstring = 'Re(Z) / Ohm cm$^2$'
ystring = '-Im(Z) / Ohm cm$^2$'

class Plotter:
    def __init__(self, zexp_re, zexp_im, omg, mode):
        self.zexp_re = zexp_re
        self.zexp_im = zexp_im
        self.omg = omg
        self.mode = mode
        if mode == 'real':
            self.zexp_prt = np.flip(self.zexp_re)
            self.ylabel = xstring
        else:
            self.zexp_prt = np.flip(self.zexp_im)
            self.ylabel = ystring

        self.fHz = np.flip(omg / (2 * np.pi))
        self.fmin = self.floor_power_of_10(np.min(self.fHz))
        self.fmax = self.ceil_power_of_10(np.max(self.fHz))
        plt.rcParams.update({'font.size': 16})
        return

    def ceil_power_of_10(self, x):
        logx = np.log10(x)
        pow = np.ceil(logx)
        return 10**pow

    def floor_power_of_10(self, x):
        logx = np.log10(x)
        pow = np.floor(logx)
        return 10**pow

    def plotGfun(self, gfun, fname, ksave, lab):
        plt.style.use('seaborn-v0_8-whitegrid')
        plt.figure(num=1, figsize=(8.5, 6.5))
        plt.tight_layout()

        Gfun = np.flip(gfun)
        plt.scatter(self.fHz, Gfun, marker='.', color='navy')
        plt.annotate(lab, xy=(0.6, 0.9), xycoords='axes fraction')
        plt.plot(self.fHz, Gfun, color='navy', lw=1)
        ymin = 0.0
        ymax = np.max(Gfun)
        plt.axis((self.fmin, self.fmax, 1.2 * ymin, 1.2 * ymax))
        plt.xscale('log')
        plt.grid(visible=True, which='major')
        plt.grid(visible=True, which='minor')
        plt.ylabel('Dimensionless DRT')
        plt.xlabel('Frequency / Hz')
        if ksave == 1:
            np.savetxt(fname + '.dat',
                       np.transpose([self.fHz, Gfun]), fmt="%e")
            plt.savefig(fname + '.pdf', dpi=300)
        plt.show()
        plt.close()
        return

    def plotshow_Z(self, zmodel, fname, keysave, lab):
        plt.style.use('seaborn-v0_8-whitegrid')
        plt.figure(num=1, figsize=(8.5, 6.5))
        plt.tight_layout()
        plt.scatter(self.fHz, self.zexp_prt, color='navy', marker='.', label='experiment')
        plt.scatter(self.fHz, zmodel, s=30, facecolors='none', edgecolors='r', label='fitted')
        plt.annotate(lab, xy=(0.6, 0.9), xycoords='axes fraction')
        plt.legend(loc='best')
        ymin = 0
        ymax = np.max(self.zexp_prt)
        plt.axis((self.fmin, self.fmax, ymin, 1.2 * ymax))
        plt.xscale('log')
        plt.grid(visible=True, which='major')
        plt.grid(visible=True, which='minor')
        plt.ylabel(self.ylabel)
        plt.xlabel('Frequency / Hz')
        if keysave == 1:
            np.savetxt(fname + '.dat',
                       np.transpose([self.fHz, self.zexp_prt, zmodel]), fmt="%e")
            plt.savefig(fname + '.pdf', dpi=300)
        plt.show()
        plt.close()
        return

    def plotshow_ZNyq(self, zmodel, fname, keysave, lab):
        plt.style.use('seaborn-v0_8-whitegrid')
        plt.figure(num=1, figsize=(8.5, 6.5))
        plt.tight_layout()
        plt.scatter(self.zexp_re, self.zexp_im, color='navy', marker='.', label='experiment')
        plt.scatter(zmodel.real, zmodel.imag, s=30, facecolors='none', edgecolors='r', label='fitted')
        plt.axis('scaled')
        plt.legend(loc='best')
        plt.annotate(lab, xy=(0.6, 0.9), xycoords='axes fraction')
        plt.ylabel(ystring)
        plt.xlabel(xstring)
        if keysave == 1:
            np.savetxt(fname + '.dat',
                       np.transpose([self.fHz, self.zexp_re, self.zexp_im, zmodel.real, zmodel.imag]), fmt="%e")
            plt.savefig(fname + '.pdf', dpi=300)
        plt.show()
        plt.close()
        return

    def plotNyq(self,lab):
        plt.style.use('seaborn-v0_8-whitegrid')
        plt.figure(num=1, figsize=(8.5, 6.5))
        plt.tight_layout()
        plt.scatter(self.zexp_re, self.zexp_im, marker='.', label=lab)
        # plt.scatter(zmodel.real, - zmodel.imag, s=30, facecolors='none', edgecolors='r')
        plt.legend()
        xmin = np.min(np.concatenate([self.zexp_re]))
        xmax = np.max(np.concatenate([self.zexp_re]))
        plt.axis((1.05 * xmin, 1.05 * xmax, 0, 1.05 * (xmax - xmin)))
        plt.axis('scaled')
        plt.ylabel(ystring)
        plt.xlabel(xstring)
        plt.show()
        plt.close()
        return

    def plotLambda(self, resid, solnorm, arrlam, fname, lab, ksave):
        plt.style.use('seaborn-v0_8-whitegrid')
        plt.figure(num=1, figsize=(9.5, 6.5))
        plt.tight_layout()
        plt.scatter(resid, solnorm, marker='+')
        plt.annotate(lab, xy=(0.9, 0.9), xycoords='axes fraction')
        ymin = self.floor_power_of_10(np.min(solnorm))
        ymax = self.ceil_power_of_10(np.max(solnorm))
        xmin = self.floor_power_of_10(np.min(resid))
        xmax = self.ceil_power_of_10(np.max(resid))
        plt.axis((xmin, xmax, ymin, ymax))
        plt.xscale('log')
        plt.yscale('log')
        plt.grid(visible=True, which='major')
        plt.grid(visible=True, which='minor')
        plt.ylabel(r'Solution norm $|| x ||$')
        plt.xlabel(r'Residual $||A x - b||$')
        plt.rcParams.update({'font.size': 8})
        for a, b, c in zip(resid, solnorm, arrlam):
            plt.text(a, b, "{:.0e}".format(c))
        if ksave == 1:
            plt.savefig(fname + '.pdf', dpi=300)
        plt.rcParams.update({'font.size': 18})
        plt.show()
        plt.close()
        return

    def plotGfun_tau(self, tau, gfun, fname, ksave, lab):
        plt.style.use('seaborn-v0_8-whitegrid')
        plt.figure(num=1, figsize=(8.5, 6.5))
        plt.tight_layout()
        plt.scatter(tau, gfun, marker='.', color='navy')
        plt.annotate(lab, xy=(0.2, 0.9), xycoords='axes fraction')
        plt.plot(tau, gfun, color='navy', lw=1)
        plt.xscale('log')
        plt.grid(visible=True, which='major')
        plt.grid(visible=True, which='minor')
        plt.ylabel('Dimensionless DRT')
        plt.xlabel('tau / s')
        if ksave == 1:
            plt.savefig(fname + '.pdf', dpi=300)
        plt.show()
        plt.close()
        return
