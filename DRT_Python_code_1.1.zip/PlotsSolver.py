import matplotlib.pyplot as plt
import numpy as np

xstring = 'Re(Z) / Ohm cm$^2$'
ystring = '-Im(Z) / Ohm cm$^2$'

class Plotter:
    def __init__(self, zexp_re, zexp_im, omg, mode):
        self.zexp_re = zexp_re
        self.zexp_im = zexp_im
        self.omg = omg
        self.mode = mode
        if mode == 'real':
            self.zexp_prt = np.flip(self.zexp_re)
            self.ylabel = 'Re(Z) / Ohm cm^2'
        else:
            self.zexp_prt = np.flip(self.zexp_im)
            self.ylabel = '-Im(Z) / Ohm cm^2'
        self.fHz = np.flip(omg / (2 * np.pi))
        self.fmin = self.floor_power_of_10(np.min(self.fHz))
        self.fmax = self.ceil_power_of_10(np.max(self.fHz))
        plt.rcParams.update({'font.size': 20})

    def ceil_power_of_10(self, x):
        logx = np.log10(x)
        pow = np.ceil(logx)
        return 10**pow

    def floor_power_of_10(self, x):
        logx = np.log10(x)
        pow = np.floor(logx)
        return 10**pow

    def plotgamma_hires(self, gamma_tau, fname):
        gammaf = np.flip(gamma_tau)
        plt.figure(num=1, figsize=(8.5, 6.5), dpi=300)
        plt.tight_layout()
        plt.scatter(self.fHz, gammaf, color='blue', marker='+')
        plt.plot(self.fHz, gammaf, color='blue', lw=1)
        ymin = np.min(gammaf)
        ymax = np.max(gammaf)
        plt.axis([self.fmin, self.fmax, 1.2 * ymin, 1.2 * ymax])
        plt.xscale('log')
        plt.grid(b=True, which='major')
        plt.grid(b=True, which='minor')
        plt.ylabel('DRT / 1/s')
        plt.xlabel('Frequency / Hz')
        plt.savefig(fname + '.pdf')

    def plotgamma(self, gamma_tau, fname, keysave):
        gammaf = np.flip(gamma_tau)
        Gfun = gammaf / (2 * np.pi * self.fHz)
        plt.figure(num=1, figsize=(8.5, 6.5), dpi=120)
        plt.tight_layout()
        plt.scatter(self.fHz, gammaf, marker='+')
        plt.plot(self.fHz, gammaf, color='blue', lw=1)
        ymin = np.min(gammaf)
        ymax = np.max(gammaf)
        plt.axis([self.fmin, self.fmax, 1.2 * ymin, 1.2 * ymax])
        plt.xscale('log')
        plt.grid(b=True, which='major')
        plt.grid(b=True, which='minor')
        plt.ylabel('DRT / 1/s')
        plt.xlabel('Frequency / Hz')
        if keysave == 1:
            np.savetxt(fname + '.dat',
                       np.transpose([self.fHz, gammaf, Gfun]), fmt="%f")
            self.plotgamma_hires(gamma_tau, fname)
        plt.show()
        
    def plotGfun(self, gamma_tau, fname, keysave):
        gammaf = np.flip(gamma_tau)
        Gfun = gammaf / (2 * np.pi * self.fHz)
        plt.figure(num=1, figsize=(8.5, 6.5), dpi=120)
        plt.tight_layout()
        plt.scatter(self.fHz, Gfun, marker='+')
        plt.plot(self.fHz, Gfun, color='blue', lw=1)
        ymin = 0.0
        ymax = np.max(Gfun)
        plt.axis([self.fmin, self.fmax, 1.2 * ymin, 1.2 * ymax])
        plt.xscale('log')
        plt.grid(b=True, which='major')
        plt.grid(b=True, which='minor')
        plt.ylabel('dimensionless DRT')
        plt.xlabel('Frequency / Hz')
        if keysave == 1:
            self.plotGfun_hires(gamma_tau, fname)
        plt.show()

    def plotGfun_hires(self, gamma_tau, fname):
        gammaf = np.flip(gamma_tau)
        Gfun = gammaf / (2 * np.pi * self.fHz)
        plt.figure(num=1, figsize=(8.5, 6.5), dpi=300)
        plt.tight_layout()
        plt.scatter(self.fHz, Gfun, marker='+', color='blue')
        plt.plot(self.fHz, Gfun, color='blue', lw=1)
        ymin = 0.0
        ymax = np.max(Gfun)
        plt.axis([self.fmin, self.fmax, 1.2 * ymin, 1.2 * ymax])
        plt.xscale('log')
        plt.grid(b=True, which='major')
        plt.grid(b=True, which='minor')
        plt.ylabel('dimensionless DRT')
        plt.xlabel('Frequency / Hz')
        plt.savefig(fname + '.pdf')

    def plot_Z_hires(self, zmodel, fname):
        plt.figure(num=1, figsize=(8.5, 6.5), dpi=300)
        plt.tight_layout()
        plt.scatter(self.fHz, self.zexp_prt, color='blue', marker='.')
        plt.scatter(self.fHz, zmodel, s=30, facecolors='none', edgecolors='r')
        ymin = 0
        ymax = np.max(self.zexp_prt)
        plt.axis([self.fmin, self.fmax, ymin, 1.2 * ymax])
        plt.xscale('log')
        plt.grid(b=True, which='major')
        plt.grid(b=True, which='minor')
        plt.ylabel(self.ylabel)
        plt.xlabel('Frequency / Hz')
        plt.savefig(fname + '.pdf')

    def plotshow_Z(self, zmodel, fname, keysave):
        plt.figure(num=1, figsize=(8.5, 6.5), dpi=120)
        plt.tight_layout()
        plt.scatter(self.fHz, self.zexp_prt, color='blue', marker='.')
        plt.scatter(self.fHz, zmodel, s=30, facecolors='none', edgecolors='r')
        ymin = 0
        ymax = np.max(self.zexp_prt)
        plt.axis([self.fmin, self.fmax, ymin, 1.2 * ymax])
        plt.xscale('log')
        plt.grid(b=True, which='major')
        plt.grid(b=True, which='minor')
        plt.ylabel(self.ylabel)
        plt.xlabel('Frequency / Hz')
        if keysave == 1:
            np.savetxt(fname + '.dat',
                       np.transpose([self.fHz, self.zexp_prt, zmodel]), fmt="%f")
            self.plot_Z_hires(zmodel, fname)
        plt.show()

    def plotNyq(self, zmodel):
        plt.figure(num=1, figsize=(8.5, 6.5), dpi=120)
        plt.tight_layout()
        plt.scatter(self.zexp_re, self.zexp_im, marker='.')
        plt.scatter(zmodel.real, - zmodel.imag, s=30, facecolors='none', edgecolors='r')
        xmin = np.min(np.concatenate([self.zexp_re, zmodel.real]))
        xmax = np.max(np.concatenate([self.zexp_re, zmodel.real]))
        plt.axis([1.05 * xmin, 1.05 * xmax, 0, 1.05 * (xmax - xmin)])
        plt.ylabel(ystring)
        plt.xlabel(xstring)
        plt.show()

    def plotLambda(self, resid, solnorm, arrlam, fname):
        plt.figure(num=1, figsize=(8.5, 6.5), dpi=120)
        plt.tight_layout()
        plt.scatter(resid, solnorm, marker='+')
        ymin = self.floor_power_of_10(np.min(solnorm))
        ymax = self.ceil_power_of_10(np.max(solnorm))
        xmin = self.floor_power_of_10(np.min(resid))
        xmax = self.ceil_power_of_10(np.max(resid))
        plt.axis([xmin, xmax, ymin, ymax])
        plt.xscale('log')
        plt.yscale('log')
        plt.grid(b=True, which='major')
        plt.grid(b=True, which='minor')
        plt.ylabel('solution norm ||$x$||')
        plt.xlabel('residual ||$A x - b$||')
        plt.rcParams.update({'font.size': 8})
        for a, b, c in zip(resid, solnorm, arrlam):
            plt.text(a, b, "{:.0e}".format(c))
        plt.savefig(fname + '.pdf')
        plt.rcParams.update({'font.size': 20})
        plt.show()
