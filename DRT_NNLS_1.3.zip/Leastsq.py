import numpy as np
from Solver import TikhSolver
from PlotsSolver import Plotter


class LeastsqMin(TikhSolver):   # --- 
    def __init__(self, omg, zre, zim, fname, mode='real'):
        super().__init__(omg, zre, zim, mode)

        self.omg = omg
        self.zexp_re = zre
        self.zexp_im = zim

        self.fname = fname
        self.mode = mode
        if mode == 'real':
            self.fsuffix = 'zre'
        else:
            self.fsuffix = 'zim'

        # self.gfun_init, dummy = self.Tikh_solver(self.lamT)
        self.fHz = self.omg / (2 * np.pi)
        return

    def find_lambda(self):
        kmax, lam1 = 32, 1e-16
        solnorm = np.zeros(kmax, dtype=np.float64)
        resid = np.zeros(kmax, dtype=np.float64)
        lamTikh = np.zeros(kmax, dtype=np.float64)
        dlnr = np.zeros(kmax, dtype=np.float64)
        sq10 = np.sqrt(10)
        for k in range(kmax):
            lamTikh[k] = lam1
            gfun, dum = self.Tikh_solver(lam1)
            resid[k] = self.residual_norm(gfun)
            solnorm[k] = np.sqrt(np.sum(gfun**2))
            if k > 0:
                dlnr[k] = np.log10(resid[k] / resid[k - 1])
            lam1 *= sq10

        kbest = np.argmax(dlnr > 0.02) - 1
        return resid, solnorm, lamTikh, kbest

    def driver(self):   # --- omega must be in descending order!
        myplots = Plotter(self.zexp_re, self.zexp_im, self.omg, self.mode)

        resid, solnorm, arrlamT, kopt = self.find_lambda()
        myplots.plotLambda(resid, solnorm, arrlamT,
                           self.fname + '_lambda_T', r'$\lambda_T$', 1)
        myplots.plotNyq('Nyquist spectrum')

        self.lamT = arrlamT[kopt]
        newlam = self.lamT
        print(f'Suggested optimal lambdaT: {self.lamT:9.2e}')
        try:
            newlam = float(input('New lambdaT: (press enter to keep suggested)'))
        except ValueError:
            pass

        if isinstance(newlam, float):
            self.lamT = newlam

        gfun, rpoly = self.Tikh_solver(self.lamT)
        print(f'lamT = {self.lamT:9.2e}')
        print('rpol =', rpoly, ', Rpol = ', self.rpol)

        resfin , lhsfin  = self.Tikh_residual_norm(gfun, self.lamT)
        print('Tikhonov residual: ', resfin)
        print('Tikhonov lhs norm: ', lhsfin)

        # myplots.plotgamma(gamres, self.fname + 'gamma', 1, '')
        myplots.plotGfun(gfun, self.fname + 'Gfun', 1, 'G-function')
        myplots.plotGfun_tau(self.tau, gfun, self.fname + 'Gfun_vs_tau', 1, 'G-function')
        zmod = self.Zmodel_imre(gfun)
        myplots.plotshow_Z(zmod, self.fname + self.fsuffix, 1, '')
        peakparms = self.rpol_peaks(gfun)

        print('Peak frequencies (beta):   ', ''.join(['{:.5f}  '.format(item) for item in peakparms[0]]))
        print('Peak polarizations (beta): ', ''.join(['{:.5f}  '.format(item) for item in peakparms[1]]))
        print('Peak polriz Ohm*cm2(beta): ', ''.join(['{:.5f}  '.format(item) for item in peakparms[2]]))
        return
